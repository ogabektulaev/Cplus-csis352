//Ogabek Tulaev, jj0565yv
//CSIS 352-01
//Date: 04/03/2023

Assignment 5 
==========================================================
This program takes infix expression via user input and
evaluates the result by constructing binary tree. 


*Please, avoid spaces in the input.
*The infix expression can consist of operands(double), 
arithmetic operators (^ * / % + -), and parentheses.
*The infix expression is entered on one line.

*Program can handle invalid input using exceptions

tulaev#.zip 
==========================================================
main.cpp
tree.cpp
tree.h
treeBuilding.h
README.txt
makefile



How to Run:
==========================================================
1. Type "make" into the terminal while in /tulaev#/ to 
compile program.
2. Type "prog5" to run the program.
3. Enter an infix expression.	
4. Enter "make clean" to remove files created from compiling.

Example output:
==========================================================
"""""
Enter infix expression: (2+(5*8))/6
Building a tree...
Result: 7

""""


Bugtesting
==========================================================
Please, let me know if you find any bugs.

jj0565yv@go.minnstate.edu


Others
==========================================================
The program is made in collaboration with Asadbek.
He mainly worked on exception part of the program.
