#ifndef TERNARYSEARCHNONREC_H
#define TERNARYSEARCHNONREC_H

#include <iostream>
using namespace std;


int ternarySearchNonRecursive(int arr[], int n, int key);

#endif
