#ifndef TERNARYSEARCHRECURSIVE_H
#define TERNARYSEARCHRECURSIVE_H

#include <iostream>
using namespace std;


int ternarySearchRecursive(int arr[], int left, int right, int key);

#endif
