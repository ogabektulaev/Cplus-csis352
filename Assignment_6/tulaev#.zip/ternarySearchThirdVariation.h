#ifndef TERNARYSEARCHTHIRDVARIATION_H
#define TERNARYSEARCHTHIRDVARIATION_H

#include <iostream>
using namespace std;


int ternarySearchThirdVariation(int arr[], int n, int key);

#endif
